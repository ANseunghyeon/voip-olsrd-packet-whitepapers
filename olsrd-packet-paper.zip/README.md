# olsrd 0.6.8 패킷 구조 도식

olsr.org olsrd **v0.6.8** (tag `v0.6.8`, 2014-12-29, commit `51ac86b`) 소스의 직렬화 코드를 기준으로 만든 OLSR 패킷 바이트 도식입니다.
LQ_HELLO(201), LQ_TC(202), MID(3), HNA(4) 메시지를 32비트 행 그리드와 hexdump로 보여주고, 가상 토폴로지 기반 예시 값을 채웠습니다.

## 파일

| 파일 | 용도 |
| --- | --- |
| `interactive.html` | 화면용. 필드나 hexdump 바이트에 마우스를 올리면 대응 위치가 강조되고 오프셋·설명이 표시됨 |
| `print.html` | 인쇄/PDF용. hover 설명을 각 도식 아래 **필드 상세 표**(오프셋·크기·값·해석·설명)로 풀어 둠. A4 인쇄 스타일 포함 |
| `olsrd-0.6.8-packets.pdf` | `print.html`을 Chromium으로 A4 출력한 PDF |

브라우저에서 `print.html`을 열고 인쇄(배경 그래픽 켜기)하면 같은 PDF를 다시 만들 수 있습니다.

## 근거 소스 (olsrd v0.6.8)

- `src/olsr_protocol.h` — 메시지 구조체, 상수, link code 매크로
- `src/lq_packet.h`, `src/lq_packet.c` — LQ_HELLO / LQ_TC 생성·직렬화
- `src/build_msg.c` — MID / HNA (및 RFC HELLO / TC) 직렬화
- `src/net_olsr.c` — `net_output()`: 패킷 헤더(길이, 패킷 시퀀스)
- `src/lq_plugin_default_ff.c` — etx_ff LQ 4바이트 `[LQ][NLQ][0][0]`
- `src/mantissa.c` — vtime/htime 인코딩
- `src/olsr_cfg.h`, `src/cfgparser/olsrd_conf.c` — 기본값 (LQ level 2, etx_ff, fish-eye, 포트 698 등)

구조체 크기와 vtime 값(2 s → `0x05`, 20 s → `0x48`, 300 s → `0x2C` = 288 s)은 v0.6.8 헤더와 `mantissa.c`로 컴파일한 검증 프로그램 출력과 일치합니다.
예시의 IP 주소, LQ 값, 시퀀스 번호는 설명용 가상 값입니다.
